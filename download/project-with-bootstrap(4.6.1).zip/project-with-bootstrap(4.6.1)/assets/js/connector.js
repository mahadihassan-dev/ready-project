// App File added
import ('./app.js');

// MainJs
import ('./main.js');

// validation 
import ('./validation.js');

// VendorJs
import ('../vendor/vendor.js');